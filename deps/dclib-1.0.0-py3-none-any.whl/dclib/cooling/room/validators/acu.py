from loguru import logger
from typing import OrderedDict

from dclib.cooling.room.facilities.acu import ACU

from dclib.models.composite import Model
from dclib.models.geometry import ACUGeometryModel
from dclib.models.cooling import ACUCoolingModel
from dclib.models.power import ACUPowerModel
from dclib.models.control import ACUControlModel

from dclib.data import ACUInputs

class ACUValidator:
    """ A class to validate ACUs of a building """
    @classmethod
    def validate(
        cls,
        acus: OrderedDict[str, ACU],
        models: Model,
        inputs: OrderedDict[str, ACUInputs]
    ) -> None:
        for acu_id, acu in acus.items():
            acu.uid = acu_id if acu.uid == "" else acu.uid
            acu.cooling.oa.uid = f"{acu_id} outdoor air system"
            if models.geometry_models is not None and  models.geometry_models.acus is not None:
                cls._validate_geometry_models(acu, models.geometry_models.acus)
            else:
                logger.warning(
                    f"ACU geometry model is not defined in the model. "
                    "Run energy simulation only without geometry properties."
                )
            if models.cooling_models is not None and models.cooling_models.acus is not None:
                cls._validate_cooling_models(acu, models.cooling_models.acus)
            else:
                logger.warning(
                    f"ACU cooling model is not defined in the model. "
                    f"Run cfd simulation only without cooling properties."
                )
            if models.control_models is not None and models.control_models.acus is not None:
                cls._validate_controller_models(acu, models.control_models.acus)
            else:
                logger.warning(
                    f"ACU controller model is not defined in the model. "
                    f"Run cfd simulation only without controller properties."
                )
            if models.power_models is not None and models.power_models.acus is not None:
                cls._validate_power_models(acu, models.power_models.acus)
            else:
                logger.warning(
                    f"ACU power model is not defined in the model. "
                    "Run cfd simulation only without power properties."
                )
            if inputs is not None:
                cls._validate_inputs(acu, inputs)
            else:
                logger.warning(
                    f"ACU inputs are not defined in the model. "
                    "Run energy simulation only without inputs."
                )

    @classmethod
    def _validate_geometry_models(
        cls,
        acu: ACU,
        models: OrderedDict[str, ACUGeometryModel]
    ) -> None:
        model_name = acu.geometry.model
        if isinstance(acu, ACU) and model_name is not None:
            acu.geometry.size = models.get(model_name).size
            acu.geometry.supply_face = models.get(model_name).supply_face
            acu.geometry.return_face = models.get(model_name).return_face
        else:
            raise ValueError(
                f"Invalid model name for: {type(acu)} {acu.uid}: "
                f"The object geometry model is not defined."
            )

    @classmethod
    def _validate_cooling_models(
        cls,
        acu: ACU,
        acu_models: OrderedDict[str, ACUCoolingModel]
    ) -> None:
        model_name = acu.cooling.model
        if isinstance(acu, ACU) and model_name is not None:
            acu.cooling.cooling_type = acu_models.get(model_name).cooling_type
            acu.cooling.cooling_capacity = acu_models.get(model_name).cooling_capacity
            acu.cooling.pressure_rise = acu_models.get(model_name).pressure_rise
            acu.cooling.maximum_flow_rate = acu_models.get(model_name).maximum_flow_rate
            acu.cooling.design_water_flow_rate = acu_models.get(model_name).design_water_flow_rate
            acu.cooling.design_air_flow_rate = acu_models.get(model_name).design_air_flow_rate
            acu.cooling.design_inlet_water_temperature = acu_models.get(model_name).design_inlet_water_temperature
            acu.cooling.design_inlet_air_temperature = acu_models.get(model_name).design_inlet_air_temperature
            acu.cooling.design_outlet_air_temperature = acu_models.get(model_name).design_outlet_air_temperature
            acu.cooling.design_inlet_air_humidity_ratio = acu_models.get(model_name).design_inlet_air_humidity_ratio
            acu.cooling.design_outlet_air_humidity_ratio = acu_models.get(model_name).design_outlet_air_humidity_ratio
            acu.cooling.design_water_temperature_difference = acu_models.get(model_name).design_water_temperature_difference
            acu.cooling.condensate_collection_water_storage_tank_name = acu_models.get(model_name).condensate_collection_water_storage_tank_name
            acu.cooling.type_of_analysis = acu_models.get(model_name).type_of_analysis
            acu.cooling.heat_exchanger_configuration = acu_models.get(model_name).heat_exchanger_configuration
        else:
            raise ValueError(
                f"Invalid model name for: {type(acu)} {acu.uid}: "
                f"The object cooling model is not defined."
            )

    @classmethod
    def _validate_power_models(
        cls,
        acu: ACU,
        acu_models: OrderedDict[str, ACUPowerModel]
    ) -> None:
        model_name = acu.power.model
        if isinstance(acu, ACU) and model_name is not None:
            acu.power.fan_total_efficiency = acu_models.get(model_name).fan_total_efficiency
            acu.power.fan_power_minimum_flow_rate_input_method = acu_models.get(model_name).fan_power_minimum_flow_rate_input_method
            acu.power.fan_power_minimum_flow_fraction = acu_models.get(model_name).fan_power_minimum_flow_fraction
            acu.power.fan_power_minimum_air_flow_rate = acu_models.get(model_name).fan_power_minimum_air_flow_rate
            acu.power.motor_efficiency = acu_models.get(model_name).motor_efficiency
            acu.power.motor_in_airstream_fraction = acu_models.get(model_name).motor_in_airstream_fraction
            acu.power.fan_power_coefficient_1 = acu_models.get(model_name).fan_power_coefficient_1
            acu.power.fan_power_coefficient_2 = acu_models.get(model_name).fan_power_coefficient_2
            acu.power.fan_power_coefficient_3 = acu_models.get(model_name).fan_power_coefficient_3
            acu.power.fan_power_coefficient_4 = acu_models.get(model_name).fan_power_coefficient_4
            acu.power.fan_power_coefficient_5 = acu_models.get(model_name).fan_power_coefficient_5
        else:
            raise ValueError(
                f"Invalid model name for: {type(acu)} {acu.uid}: "
                f"The object power model is not defined."
            )

    @classmethod
    def _validate_controller_models(
        cls,
        acu: ACU,
        acu_models: OrderedDict[str, ACUControlModel]
    ) -> None:
        model_name = acu.controller.model
        if isinstance(acu, ACU) and model_name is not None:
            acu.controller.control_variable = acu_models.get(model_name).control_variable
            acu.controller.supply_air_temperature_setpoint = acu_models.get(model_name).supply_air_temperature_setpoint
            acu.controller.supply_air_humidity_ratio_setpoint = acu_models.get(model_name).supply_air_humidity_ratio_setpoint
            acu.controller.supply_air_maximum_humidity_ratio_setpoint = acu_models.get(model_name).supply_air_maximum_humidity_ratio_setpoint
            acu.controller.supply_air_minimum_humidity_ratio_setpoint = acu_models.get(model_name).supply_air_minimum_humidity_ratio_setpoint
        else:
            raise ValueError(
                f"Invalid model name for: {type(acu)} {acu.uid}: "
                f"The object controller model is not defined."
            )
        
    @classmethod
    def _validate_inputs(
        cls,
        acu: ACU,
        inputs: OrderedDict[str, ACUInputs]
    ) -> None:
        input = inputs.get(acu.uid)
        if isinstance(acu, ACU) and input is not None:
            acu.cooling.operating.supply_air_temperature = input.supply_air_temperature
            acu.cooling.operating.supply_air_volume_flow_rate = input.supply_air_volume_flow_rate
        else:
            raise ValueError(
                f"Invalid model name for: {type(acu)} {acu.uid}: "
                f"The object inputs model is not defined."
            )
