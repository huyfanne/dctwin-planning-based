"""Duct model
"""
from typing import Optional

from dclib.models.base import BaseModel


class Duct(BaseModel):
    # TODO: Add duct
    uid: Optional[str] = ""
