from typing import Optional
from pydantic import Field

from dclib.models.cooling.cooling_tower import CoolingTowerCoolingModel
from dclib.models.power.cooling_tower import CoolingTowerPowerModel


class CoolingTowerCooling(CoolingTowerCoolingModel):
    """
    Cooling tower cooling status object. It inherits from CoolingTowerCoolingModel where the cooling parameters of
    the cooling tower are defined.
    :param model: the cooling model name of the cooling tower
    """
    model: Optional[str] = "YorkCalcUserDefined"


class CoolingTowerPower(CoolingTowerPowerModel):
    """
    Cooling tower power status object. It inherits from CoolingTowerPowerModel where the power parameters of the
    cooling tower are defined.
    :param model: the power model name of the cooling tower
    """
    model: Optional[str] = None


class CoolingTower(CoolingTowerCoolingModel):
    """
    Cooling tower object. It inherits from CoolingTowerCoolingModel and CoolingTowerPowerModel where the cooling and
    power parameters of the cooling tower are defined.
    :param cooling: the cooling object of the cooling tower
    :param power: the power object of the cooling tower
    """
    uid: Optional[str] = ""
    cooling: Optional[CoolingTowerCooling] = Field(default_factory=CoolingTowerCooling)
    power: Optional[CoolingTowerPower] = Field(default_factory=CoolingTowerPower)
    meta: Optional[dict] = None
