from typing import Optional, OrderedDict
from dclib.models.base import BaseModel


from dclib.cooling.room.facilities.acu import ACU

from .chiller import Chiller
from .pump import Pump
from .cooling_tower import CoolingTower
from .pipe import Pipe


class Components(BaseModel):
    pipes: Optional[OrderedDict[str, Pipe]] = None
    chillers: Optional[OrderedDict[str, Chiller]] = None
    pumps: Optional[OrderedDict[str, Pump]] = None
    cooling_towers: Optional[OrderedDict[str, CoolingTower]] = None
    acu: Optional[OrderedDict[str, ACU]] = None  # can only have one ACU in a branch


__all__ = [
    "Pipe",
    "Chiller",
    "Pump",
    "CoolingTower",
    "Components"
]
