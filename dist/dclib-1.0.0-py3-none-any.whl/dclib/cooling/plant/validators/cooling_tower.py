from typing import OrderedDict

from dclib.cooling.plant.facilities.cooling_tower import CoolingTower
from dclib.models.cooling.cooling_tower import CoolingTowerCoolingModel
from dclib.models.power.cooling_tower import CoolingTowerPowerModel

class CoolingTowerValidator:
    """ A class to validate cooling towers of a building """
    @classmethod
    def validate(
        cls,
        cooling_towers: OrderedDict[str, CoolingTower],
        cooling_models: OrderedDict[str, CoolingTowerCoolingModel],
        power_models: OrderedDict[str, CoolingTowerPowerModel],
    ) -> None:
        """
        Validate the cooling towers of the loop. In the validation, we fill in the parameters of the cooling towers by
        using the parameters defined in the cooling and power models.
        """
        for cooling_tower_name, cooling_tower in cooling_towers.items():
            cooling_tower.uid = cooling_tower_name if cooling_tower.uid == "" else cooling_tower.uid

            cooling_model = cooling_models.get(cooling_tower.cooling.model, None)
            power_model = power_models.get(cooling_tower.power.model, None)

            """Fill in cooling model parameters"""
            cooling_tower.cooling.model_type = cooling_model.model_type
            cooling_tower.cooling.minimum_air_flow_rate_ratio = cooling_model.minimum_air_flow_rate_ratio
            cooling_tower.cooling.model_coefficient_name = cooling_model.model_coefficient_name
            cooling_tower.cooling.design_range_temperature = cooling_model.design_range_temperature
            cooling_tower.cooling.fraction_of_tower_capacity_in_free_convection_regime \
                = cooling_model.fraction_of_tower_capacity_in_free_convection_regime
            cooling_tower.cooling.basin_heater_capacity = cooling_model.basin_heater_capacity
            cooling_tower.cooling.basin_heater_setpoint_temperature = cooling_model.basin_heater_setpoint_temperature
            cooling_tower.cooling.basin_heater_operating_schedule_name \
                = cooling_model.basin_heater_operating_schedule_name
            cooling_tower.cooling.evaporation_loss_mode = cooling_model.evaporation_loss_mode
            cooling_tower.cooling.evaporation_loss_factor = cooling_model.evaporation_loss_factor
            cooling_tower.cooling.drift_loss_percent = cooling_model.drift_loss_percent
            cooling_tower.cooling.blowdown_calculation_mode = cooling_model.blowdown_calculation_mode
            cooling_tower.cooling.blowdown_concentration_ratio = cooling_model.blowdown_concentration_ratio
            cooling_tower.cooling.blowdown_makeup_water_usage_schedule_name \
                = cooling_model.blowdown_makeup_water_usage_schedule_name
            cooling_tower.cooling.supply_water_storage_tank_name = cooling_model.supply_water_storage_tank_name
            cooling_tower.cooling.outdoor_air_inlet_node_name = cooling_model.outdoor_air_inlet_node_name
            cooling_tower.cooling.number_of_cells = cooling_model.number_of_cells
            cooling_tower.cooling.cell_control = cooling_model.cell_control
            cooling_tower.cooling.cell_minimum_water_flow_rate_fraction \
                = cooling_model.cell_minimum_water_flow_rate_fraction
            cooling_tower.cooling.cell_maximum_water_flow_rate_fraction \
                = cooling_model.cell_maximum_water_flow_rate_fraction
            cooling_tower.cooling.sizing_factor = cooling_model.sizing_factor
            cooling_tower.cooling.end_use_subcategory = cooling_model.end_use_subcategory
            cooling_tower.cooling.design_inlet_air_wet_bulb_temperature = cooling_model.design_inlet_air_wet_bulb_temperature
            cooling_tower.cooling.design_approach_temperature = cooling_model.design_approach_temperature
            cooling_tower.cooling.design_water_flow_rate = cooling_model.design_water_flow_rate
            cooling_tower.cooling.design_air_flow_rate = cooling_model.design_air_flow_rate


            """Fill in power model parameters"""
            cooling_tower.power.design_fan_power \
                = power_model.design_fan_power
            cooling_tower.power.fan_power_ratio_function_of_air_flow_rate_ratio_curve_model \
                = power_model.fan_power_ratio_function_of_air_flow_rate_ratio_curve_model
            cooling_tower.power.fan_power_ratio_function_of_air_flow_rate_ratio_curve \
                = power_model.fan_power_ratio_function_of_air_flow_rate_ratio_curve
