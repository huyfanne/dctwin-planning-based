from typing import OrderedDict

from dclib.cooling.plant.facilities.pump import Pump
from dclib.models.cooling.pump import PumpCoolingModel
from dclib.models.power.pump import PumpPowerModel
from dclib.models.control.pump import PumpControlModel

class PumpValidator:
    """ A class to validate pumps of a building """
    @classmethod
    def validate(
        cls,
        pumps: OrderedDict[str, Pump],
        cooling_models: OrderedDict[str, PumpCoolingModel],
        power_models: OrderedDict[str, PumpPowerModel],
        control_models: OrderedDict[str, PumpControlModel]
    ) -> None:
        """
        Validate the pumps of the loop. In the validation, we fill in the parameters of the pumps by using the
        parameters defined in the cooling, power and control models.
        """
        for pump_name, pump in pumps.items():
            pump.uid = pump_name if pump.uid == "" else pump.uid

            cooling_model = cooling_models.get(pump.cooling.model, None)
            power_model = power_models.get(pump.power.model, None)
            control_model = control_models.get(pump.control.model, None)

            """Fill in cooling model parameters"""
            pump.cooling.design_maximum_flow_rate = cooling_model.design_maximum_flow_rate
            pump.cooling.design_pump_head = cooling_model.design_pump_head
            pump.cooling.skin_loss_radiative_fraction = cooling_model.skin_loss_radiative_fraction
            pump.cooling.impeller_diameter = cooling_model.impeller_diameter
            pump.cooling.design_minimum_flow_rate_fraction = cooling_model.design_minimum_flow_rate_fraction

            """Fill in power model parameters"""
            pump.power.pump_curve_name = power_model.pump_curve_name
            pump.power.design_power_sizing_method = power_model.design_power_sizing_method
            pump.power.design_electric_power_per_unit_flow_rate = power_model.design_electric_power_per_unit_flow_rate
            pump.power.design_shaft_power_per_unit_flow_rate_per_unit_head \
                = power_model.design_shaft_power_per_unit_flow_rate_per_unit_head
            pump.power.design_power_consumption = power_model.design_power_consumption
            pump.power.motor_efficiency = power_model.motor_efficiency
            pump.power.fraction_of_motor_inefficiencies_to_fluid_stream \
                = power_model.fraction_of_motor_inefficiencies_to_fluid_stream
            pump.power.coefficient_1_of_the_part_load_performance_curve \
                = power_model.coefficient_1_of_the_part_load_performance_curve
            pump.power.coefficient_2_of_the_part_load_performance_curve \
                = power_model.coefficient_2_of_the_part_load_performance_curve
            pump.power.coefficient_3_of_the_part_load_performance_curve \
                = power_model.coefficient_3_of_the_part_load_performance_curve
            pump.power.coefficient_4_of_the_part_load_performance_curve \
                = power_model.coefficient_4_of_the_part_load_performance_curve

            """Fill in control model parameters"""
            pump.control.pump_control_type = control_model.pump_control_type
            pump.control.pump_flow_rate_schedule_name = control_model.pump_flow_rate_schedule_name
            pump.control.vfd_control_type = control_model.vfd_control_type
            pump.control.pump_rpm_schedule_name = control_model.pump_rpm_schedule_name
            pump.control.minimum_pressure_schedule = control_model.minimum_pressure_schedule
            pump.control.maximum_pressure_schedule = control_model.maximum_pressure_schedule
            pump.control.minimum_rpm_schedule = control_model.minimum_rpm_schedule
            pump.control.maximum_rpm_schedule = control_model.maximum_rpm_schedule
