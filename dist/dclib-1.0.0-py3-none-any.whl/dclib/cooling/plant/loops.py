from typing import Optional, OrderedDict

from dclib.models.base import BaseModel

from .facilities import Components
from .sizing import SizingPlant


class MetaPlant(BaseModel):
    """
    Metadata for defining a chiller plant. For the meta info, we define the following:
    - load_distribution_scheme: the scheme for distributing the load among the chillers
    - plant_loop_demand_calculation_scheme: the scheme for calculating the plant loop demand
    - common_pipe_simulation: the scheme for simulating the common pipe
    - setpoint_manager: whether to use setpoint manager
    """
    load_distribution_scheme: Optional[str] = "SequentialLoad"
    plant_loop_demand_calculation_scheme: Optional[str] = "SingleSetpoint"
    common_pipe_simulation: Optional[str] = "None"
    setpoint_manager: Optional[bool] = True


class Branch(BaseModel):
    """
    Branches are the basic components of a plant loop. They are used to install equipment (devices).
    Side is used to indicate the side of the branch. For example, for a chilled water loop, it will be constructed with
    three branches: 'inlet' side, 'outlet' side, and 'middle' pipe. The 'inlet' side and 'outlet' side are used to
    install pipes and pumps, while the 'middle' pipe is used to install chillers and pumps.

    :param components: the components installed on the branch
    :param side: the side of the branch
    """
    uid: Optional[str] = ""
    components: Optional[Components]
    side: Optional[str] = ""


class ChilledWaterLoops(BaseModel):
    """
    Chilled water loops are used to define the chilled water loop. It contains the following attributes:
    - supply_branches: the supply branches of the chilled water loop
    - demand_branches: the demand branches of the chilled water loop
    - sizing: the sizing parameters of the chilled water loop
    """
    uid: Optional[str] = ""
    supply_branches: OrderedDict[str, Branch]
    demand_branches: OrderedDict[str, Branch]
    sizing: SizingPlant
    meta: Optional[MetaPlant] = MetaPlant()


class CondenserWaterLoops(BaseModel):
    """
    Condenser water loops are used to define the condenser water loop. It contains the following attributes:
    - supply_branches: the supply branches of the condenser water loop
    - demand_branches: the demand branches of the condenser water loop
    - sizing: the sizing parameters of the condenser water loop
    """
    uid: Optional[str] = ""
    supply_branches: OrderedDict[str, Branch]
    demand_branches: OrderedDict[str, Branch]
    sizing: SizingPlant
    meta: Optional[MetaPlant] = MetaPlant()
