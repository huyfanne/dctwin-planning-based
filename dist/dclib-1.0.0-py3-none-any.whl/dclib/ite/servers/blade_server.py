""" Blade server class
"""

# TODO: add a new class for blade server
