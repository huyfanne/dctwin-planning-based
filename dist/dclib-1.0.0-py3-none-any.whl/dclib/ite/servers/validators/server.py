from typing import OrderedDict
from loguru import logger

from ..server import Server

from dclib.models.composite import Model
from dclib.models.cooling.server import ServerCoolingModel
from dclib.models.computing.server import ServerComputingModel
from dclib.models.geometry.server import ServerGeometryModel
from dclib.models.power.server import ServerPowerModel

from dclib.data import ServerInputs

class ServerValidator:
    """ A class to validate zone-related aspects of a building """
    @classmethod
    def validate(
        cls,
        servers: OrderedDict[str, Server],
        models: OrderedDict[str, Model],
        inputs: OrderedDict[str, ServerInputs]
    ) -> None:
        for server_id, server in servers.items():
            server.uid = server_id if server.uid == "" else server.uid
            cls._validate_geometry_models(server, models.geometry_models.servers) \
                if models.geometry_models is not None and models.geometry_models.servers is not None else None
            cls._validate_cooling_models(server, models.cooling_models.servers) \
                if models.cooling_models is not None and models.cooling_models.servers is not None else None
            cls._validate_power_models(server, models.power_models.servers) \
                if models.power_models is not None and models.power_models.servers is not None else None
            cls._validate_computing_models(server, models.computing_models.servers) \
                if models.computing_models is not None and models.computing_models.servers is not None else None
            cls._validate_inputs(server, inputs) \
                if inputs is not None else None

    @classmethod
    def _validate_geometry_models(
        cls,
        server: Server,
        models: OrderedDict[str, ServerGeometryModel]
    ) -> None:
        model_name = server.geometry.model
        if isinstance(server, Server) and model_name is not None:
            server.geometry.slot_occupation = models.get(model_name).slot_occupation
            server.geometry.width = models.get(model_name).width
            server.geometry.depth = models.get(model_name).depth
            server.geometry.inlet_face = models.get(model_name).inlet_face
            server.geometry.outlet_face = models.get(model_name).outlet_face

    @classmethod
    def _validate_power_models(
        cls,
        server: Server,
        models: OrderedDict[str, ServerPowerModel]
    ) -> None:
        model_name = server.power.model
        if isinstance(server, Server) and model_name is not None:
            server.power.rated_power = models.get(model_name).rated_power
            server.power.rated_cpu_power = models.get(model_name).rated_cpu_power
            server.power.rated_mem_power = models.get(model_name).rated_mem_power
            server.power.rated_disk_power = models.get(model_name).rated_disk_power

    @classmethod
    def _validate_computing_models(
        cls,
        server: Server,
        models: OrderedDict[str, ServerComputingModel]
    ):
        model_name = server.computing.model
        if isinstance(server, Server) and model_name is not None:
            server.computing.cpu_capacity = models.get(model_name).cpu_capacity
            server.computing.mem_capacity = models.get(model_name).mem_capacity
            server.computing.disk_capacity = models.get(model_name).disk_capacity
            server.computing.remaining_cpu = models.get(model_name).cpu_capacity
            server.computing.remaining_mem = models.get(model_name).mem_capacity
            server.computing.remaining_disk = models.get(model_name).disk_capacity
            server.computing.task_instances = {}

    @classmethod
    def _validate_cooling_models(
        cls,
        server: Server,
        models: OrderedDict[str, ServerCoolingModel]
    ) -> None:
        if isinstance(server, Server) and server.cooling.model is not None:
            model_name = server.cooling.model
            server.cooling.fan_type = models.get(model_name).fan_type
            server.cooling.volume_flow_rate_ratio = models.get(model_name).volume_flow_rate_ratio\

    @classmethod
    def _validate_inputs(
        cls,
        server: Server,
        inputs: OrderedDict[str, ServerInputs]
    ) -> None:
        input = inputs.get(server.uid)
        if isinstance(server, Server) and input is not None:
            server.power.input_power = input.input_power
        else:
            raise ValueError(
                f"Invalid model name for: {type(server)}: "
                f"The object input is not defined."
            )