from typing import Dict

from dclib.ite.servers.server import Server
from dclib.cooling.room.facilities.acu import ACU
from dclib.construction.entities.box import Box
from dclib.ite.racks.rack import Rack, RackConstruction

from dclib.ite.servers.validators import ServerValidator

from dclib.models.composite import Model
from dclib.data import ServerInputs

class RackValidator:
    """ A class to validate zone-related aspects of a building """
    @classmethod
    def validate(
        cls,
        racks: Dict,
        models: Model,
        inputs: ServerInputs
    ) -> None:
        """
        Validate the geometry of racks and constructions for each rack.
        :param racks: rack objects in a data hall.
        :param models: models for geometry, power, computing, and cooling.
        :return:
        """
        all_servers, invalid_occupation = {}, {}
        for rack_id, rack in racks.items():
            rack.uid = rack_id if rack.uid == "" else rack.uid
            cls._validate_geometry_models(rack, models.geometry_models.racks) if models.geometry_models else ValueError(
                f"Rack {rack_id} has no geometry model"
            )
            cls._validate_rack_constructions(rack.constructions, models=models, inputs=inputs)
        if invalid_occupation:
            msg = f"Server collision error:"
            for server_a, server_b in invalid_occupation.items():
                msg += f"\n{server_a} collides with {server_b}"
            raise ValueError(f"{msg}")

    @classmethod
    def _validate_rack_constructions(
        cls,
        rack_constructions: RackConstruction,
        models: Model,
        inputs: ServerInputs
    ) -> None:
        """
        Validate the geometry of servers and constructions for each server.
        :param rack_constructions: rack_constructions objects in a rack.
        :param models: models for geometry, power, computing, and cooling.
        :return:
        """
        ServerValidator.validate(
            servers=rack_constructions.servers,
            models=models,
            inputs=inputs
        )

    @classmethod
    def _validate_server_occupation(
        cls,
        rack: Rack,
        server: Server,
        server_id: str,
        occupied_rack_slot: Dict,
        invalid_occupation: Dict
    ) -> None:
        """
        Validate the occupation of a server in a rack. If the server is valid, update the occupied rack slot.
        Otherwise, raise an error.
        :param rack: rack object to be validated.
        :param server: server object to be validated.
        :param server_id: name of the server
        :param occupied_rack_slot: rack slot that is occupied by a server.
        :param invalid_occupation: indicators to identify the invalid occupation.
        :return:
        """
        server.geometry.orientation = rack.geometry.orientation
        slot_position = int(server.geometry.slot_position)
        slot_occupation = int(server.geometry.slot_occupation)
        num_slots = int(rack.geometry.slot)
        if slot_position < 1 or slot_occupation + slot_position > num_slots + 1:
            raise ValueError(
                f"invalid server slot/occupation:"
                f"Server({server_id}, slot={slot_position},"
                f"occupation={slot_occupation})"
            )
        for i in range(slot_position, slot_position + slot_occupation):
            if i not in occupied_rack_slot:
                occupied_rack_slot[i] = server_id
            else:
                invalid_occupation[server_id] = occupied_rack_slot[i]

    @classmethod
    def _validate_geometry_models(
        cls,
        obj: ACU | Server | Rack | Box,
        models: Dict
    ) -> None:
        """
        Validate the geometry of a server, rack, or box.
        :param obj:
        :param models:
        :return:
        """
        model_name = obj.geometry.model
        if model_name is not None:
            obj.geometry.size = models.get(model_name).size
            obj.geometry.slot = models.get(model_name).slot
            obj.geometry.first_slot_offset = models.get(model_name).first_slot_offset
            obj.geometry.faces = models.get(model_name).faces