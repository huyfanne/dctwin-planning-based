from typing import OrderedDict

from dclib.cooling.room.facilities import ACU
from pydantic import ValidationInfo

from dclib.cooling.plant import Plant
from dclib.cooling.plant.loops import ChilledWaterLoops, CondenserWaterLoops, MetaPlant
from dclib.cooling.plant.sizing import SizingPlant

from dclib.models.composite import Model

from dclib.room import Room

from dclib.cooling.plant.validators import CoolingTowerValidator
from dclib.cooling.plant.validators import ChillerValidator
from dclib.cooling.plant.validators import PumpValidator
from dclib.cooling.plant.validators import PipeValidator


class PlantValidator:
    """ A class to validate plant-related aspects of a building """

    @classmethod
    def validate(cls, plant: Plant, rooms: OrderedDict[str, Room], values: ValidationInfo) -> None:
        """
        Validate the plant of the building. To validate the plant, we validate the following:
        1. The chilled water loop
        2. The condenser water loop
        """
        cls._validate_loop(plant.chilled_water_loops, values.data["models"])
        cls._validate_loop(plant.condenser_water_loops, values.data["models"])
        cls._validate_chiller_connection(plant.chilled_water_loops, plant.condenser_water_loops)
        cls._validate_acu_connection(plant.chilled_water_loops, rooms)

    @classmethod
    def _validate_loop(cls, loops: OrderedDict[str, ChilledWaterLoops | CondenserWaterLoops], models: Model) -> None:
        """
        Validate the chilled water loop of the building. To validate the loop, we validate the following:
        1. The supply branches
        2. The demand branches
        3. The sizing parameters
        4. The meta parameters
        """
        for loop_name, loop in loops.items():
            loop.uid = loop_name if loop.uid == "" else loop.uid
            cls._validate_supply_branches(loop.supply_branches, models)
            cls._validate_demand_branches(loop.demand_branches, models)
            cls._validate_sizing(loop.sizing)
            cls._validate_meta_loop(loop.meta)


    @classmethod
    def _validate_chiller_connection(
        cls,
        chilled_water_loops: OrderedDict[str, ChilledWaterLoops],
        condenser_water_loops: OrderedDict[str, CondenserWaterLoops]
    ) -> None:
        """
        Validate the connection of chillers between the chilled water loop and the condenser water loop. To validate the connection,
        we validate the following:
        1. Chiller uid is unique in each loop
        2. Chiller uid in chilled water loop supply branches is the same as the one in condenser water loop demand branches
        """

        chilled_chiller_uids = set()
        condenser_chiller_uids = set()

        for loop_name, chilled_water_loop in chilled_water_loops.items():
            for branch_name, branch in chilled_water_loop.supply_branches.items():
                if branch.components.chillers:
                    for chiller_name, chiller in branch.components.chillers.items():
                        if chiller.uid in chilled_chiller_uids:
                            raise ValueError(f"Chiller {chiller.uid} is not unique in chilled water loop supply branches.")
                        chilled_chiller_uids.add(chiller.uid)

        for loop_name, condenser_water_loop in condenser_water_loops.items():
            for branch_name, branch in condenser_water_loop.demand_branches.items():
                if branch.components.chillers:
                    for chiller_name, chiller in branch.components.chillers.items():
                        if chiller.uid in condenser_chiller_uids:
                            raise ValueError(f"Chiller {chiller.uid} is not unique in condenser water loop demand branches.")
                        chiller_uid = chiller.uid
                        condenser_chiller_uids.add(chiller_uid)

        chiller_uids_missing_in_condenser = chilled_chiller_uids - condenser_chiller_uids
        chiller_uids_missing_in_chilled = condenser_chiller_uids - chilled_chiller_uids

        if chiller_uids_missing_in_condenser:
            raise ValueError(f"Chiller {chiller_uids_missing_in_condenser} is missing in condenser water loop demand branches.")
        if chiller_uids_missing_in_chilled:
            raise ValueError(f"Chiller {chiller_uids_missing_in_chilled} is missing in chilled water loop supply branches.")


    @classmethod
    def _validate_acu_connection(
        cls,
        chilled_water_loops: OrderedDict[str, ChilledWaterLoops],
        zones: OrderedDict[str, Room],
    ) -> None:
        """
        Validate the connection of acus between the chilled water loop and the zones. To validate the connection,
        we validate the following:
        1. ACU uid is unique in each chilled water loop
        2. ACU uid in chilled water loop demand branches is the same as the one in the zones
        """
        acu_uids_in_chilled_water_loops = set()
        acu_uids_in_zones = set()

        for loop_name, chilled_water_loop in chilled_water_loops.items():
            for branch_name, branch in chilled_water_loop.demand_branches.items():
                if branch.components.acu:
                    for acu_name, acu in branch.components.acu.items():
                        if acu.uid in acu_uids_in_chilled_water_loops:
                            raise ValueError(f"ACU {acu.uid} is not unique in chilled water loop demand branches.")
                        acu_uids_in_chilled_water_loops.add(acu.uid)

        for zone_name, zone in zones.items():
            for acu_name, acu in zone.constructions.acus.items():
                if acu.uid in acu_uids_in_zones:
                    raise ValueError(f"ACU {acu.uid} is not unique in zones.")
                acu_uids_in_zones.add(acu.uid)

        acu_uids_missing_in_zones = acu_uids_in_chilled_water_loops - acu_uids_in_zones
        acu_uids_missing_in_chilled_water_loops = acu_uids_in_zones - acu_uids_in_chilled_water_loops

        if acu_uids_missing_in_zones:
            raise ValueError(
                f"ACU {acu_uids_missing_in_zones} is missing in zones."
            )
        if acu_uids_missing_in_chilled_water_loops:
            raise ValueError(
                f"ACU {acu_uids_missing_in_chilled_water_loops} "
                f"is missing in chilled water loop demand branches."
            )

    @classmethod
    def _validate_supply_branches(cls, supply_branches: OrderedDict, models: Model) -> None:
        """
        Validate the supply branches of the loop. To validate each branch, we validate the following:
        1. The chillers
        2. The pumps
        3. The cooling towers
        """
        cls._validate_branches_sequences(supply_branches)
        for supply_branch_name, supply_branch in supply_branches.items():
            supply_branch.uid = supply_branch_name if supply_branch.uid == "" else supply_branch.uid
            ChillerValidator.validate(
                chillers=supply_branch.components.chillers,
                cooling_models=models.cooling_models.chillers,
                power_models=models.power_models.chillers,
                curve_models=models.curve_models
            ) if supply_branch.components.chillers else None
            PumpValidator.validate(
                pumps=supply_branch.components.pumps,
                cooling_models=models.cooling_models.pumps,
                power_models=models.power_models.pumps,
                control_models=models.control_models.pumps
            ) if supply_branch.components.pumps else None
            CoolingTowerValidator.validate(
                cooling_towers=supply_branch.components.cooling_towers,
                cooling_models=models.cooling_models.cooling_towers,
                power_models=models.power_models.cooling_towers,
            ) if supply_branch.components.cooling_towers else None
            PipeValidator.validate(
                pipes=supply_branch.components.pipes,
            ) if supply_branch.components.pipes else None

    @classmethod
    def _validate_demand_branches(cls, demand_branches: OrderedDict, models: Model) -> None:
        """
        Validate the demand branches of the loop.
        """
        cls._validate_branches_sequences(demand_branches)
        for demand_branch in demand_branches.values():
            ChillerValidator.validate(
                chillers=demand_branch.components.chillers,
                cooling_models=models.cooling_models.chillers,
                power_models=models.power_models.chillers,
                curve_models=models.curve_models
            ) if demand_branch.components.chillers else None
            PumpValidator.validate(
                pumps=demand_branch.components.pumps,
                cooling_models=models.cooling_models.pumps,
                power_models=models.power_models.pumps,
                control_models=models.control_models.pumps
            ) if demand_branch.components.pumps else None
            cls._validate_acus(
                acus=demand_branch.components.acu
            ) if demand_branch.components.acu else None
            PipeValidator.validate(
                pipes=demand_branch.components.pipes
            ) if demand_branch.components.pipes else None

    @classmethod
    def _validate_sizing(cls, sizing_plant: SizingPlant) -> None:
        """ Validate the sizing of the loop """
        pass

    @classmethod
    def _validate_branches_sequences(cls, supply_branches: OrderedDict) -> None:
        """ Validate the first and last branches in the supplyBranches dictionary """
        if not supply_branches:
            raise ValueError("supplyBranches cannot be empty")

        # Get the first and last branch names and their details
        first_branch = next(iter(supply_branches.values()))
        last_branch = next(reversed(supply_branches.values()))

        # Check if the first branch is an inlet branch
        if first_branch.side != "inlet":
            raise ValueError(f"The first supply branch must be an inlet branch")

        # Check if the last branch is an outlet branch
        if last_branch.side != "outlet":
            raise ValueError(f"The last supply branch must be an outlet branch")

    @classmethod
    def _validate_acus(
        cls,
        acus: OrderedDict[str, ACU],
    ) -> None:
        """
        Validate the acus of the loop. In the validation, we fill in the parameters of the acus by using the
        parameters defined in the cooling and power models.
        """
        for acu_name, acu in acus.items():
            acu.uid = acu_name if acu.uid == "" else acu.uid

    @classmethod
    def _validate_meta_loop(cls, meta_plant: MetaPlant) -> None:
        """ Validate the meta of the loop """
        cls._validate_load_distribution_scheme(meta_plant.load_distribution_scheme)
        cls._validate_demand_calculation_scheme(meta_plant.plant_loop_demand_calculation_scheme)
        cls._validate_common_pipe_simulation(meta_plant.common_pipe_simulation)
        cls._validate_setpoint_manager(meta_plant.setpoint_manager)

    @staticmethod
    def _validate_load_distribution_scheme(v) -> str:
        """
        Validate the load distribution scheme of the plant loop. The load distribution scheme can be one of the
        following:
        1. Optimal
        2. SequentialLoad
        3. UniformLoad
        4. UniformPLR
        5. SequentialUniformPLR
        :param v:
        :return:
        """
        scheme = ["Optimal", "SequentialLoad", "UniformLoad", "UniformPLR", "SequentialUniformPLR"]
        if v not in scheme:
            raise ValueError("Plant Load Distribution Scheme must be in {}".format(scheme))
        return v
    
    @staticmethod
    def _validate_demand_calculation_scheme(v) -> str:
        """
        Validate the demand calculation scheme of the plant loop. The demand calculation scheme can be one of the
        following:
        1. SingleSetpoint
        2. DualSetpointDeadband
        :param v:
        :return:
        """
        scheme = ["SingleSetpoint", "DualSetpointDeadband"]
        if v not in scheme:
            raise ValueError("Plant Loop Demand Calculation Scheme must be in {}".format(scheme))
        return v
    
    @staticmethod
    def _validate_common_pipe_simulation(v) -> str:
        """
        Validate the common pipe simulation of the plant loop. The common pipe simulation can be one of the following:
        1. CommonPipe
        2. TwoWayCommonPipe
        3. None
        :param v:
        :return:
        """
        pipe_simulation = ["CommonPipe", "TwoWayCommonPipe", "None"]
        if v not in pipe_simulation:
            raise ValueError("Plant Common Pipe Simulation must be in {}".format(pipe_simulation))
        return v

    @staticmethod
    def _validate_setpoint_manager(v) -> bool:
        """
        Validate the setpoint manager of the plant loop
        :param v:
        :return:
        """
        if v not in [True, False]:
            raise ValueError("Plant Setpoint Manager must be either True or False")
        return v
