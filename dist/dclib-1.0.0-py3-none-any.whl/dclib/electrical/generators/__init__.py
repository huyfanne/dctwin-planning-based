from .photovoltaic import PhotovoltaicGenerator
from .wind_turbine import WindTurbineGenerator


__all__ = [
    "PhotovoltaicGenerator",
    "WindTurbineGenerator",
]
