from .electrical_device import Light, ElectricEquipment, People


__all__ = [
    "Lights",
    "ElectricEquipment",
    "People"
]
