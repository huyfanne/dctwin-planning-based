from typing import Optional
from dclib.models.base import BaseModel


class ACUCoolingModel(BaseModel):
    """ Model of ACU cooling properties
    Please refer to the following link for more information:
    Fan: https://bigladdersoftware.com/epx/docs/9-5/input-output-reference/group-fans.html#fanvariablevolume
    Coil: https://bigladdersoftware.com/epx/docs/9-5/input-output-reference/group-heating-and-cooling-coils.html#coilcoolingwater
    """
    cooling_type: Optional[str] = "CW"  # DX, CW, etc.
    cooling_capacity: Optional[float] = 60  # unit(kW)
    pressure_rise: Optional[float] = 500.0  # unit(Pa)
    maximum_flow_rate: Optional[float | str] = "autosize"
    design_water_flow_rate: Optional[float | str] = "Autosize"
    design_air_flow_rate: Optional[float | str] = "Autosize"
    design_inlet_water_temperature: Optional[float | str] = "Autosize"
    design_inlet_air_temperature: Optional[float | str] = "Autosize"
    design_outlet_air_temperature: Optional[float | str] = "Autosize"
    design_inlet_air_humidity_ratio: Optional[float | str] = "Autosize"
    design_outlet_air_humidity_ratio: Optional[float | str] = "Autosize"
    design_water_temperature_difference: Optional[float] = 8.0
    condensate_collection_water_storage_tank_name: Optional[str] = ""
    type_of_analysis: Optional[str] = "SimpleAnalysis"
    heat_exchanger_configuration: Optional[str] = "CounterFlow"
