from typing import Optional

from dclib.models.base import BaseModel


class ServerCoolingModel(BaseModel):
    """ Model of server cooling properties
    """
    fan_type: Optional[str] = "Variable"  # Fixed (CSD) or Variable (VSD)
    volume_flow_rate: Optional[float] = 0.02  # unit (m3/s)
    volume_flow_rate_ratio: Optional[float] = 0.00005  # unit(m3/s/W)
