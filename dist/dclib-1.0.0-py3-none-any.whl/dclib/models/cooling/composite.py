from typing import Optional, OrderedDict
from .acu import ACUCoolingModel
from .chiller import ChillerCoolingModel
from .pump import PumpCoolingModel
from .cooling_tower import CoolingTowerCoolingModel
from .server import ServerCoolingModel

from dclib.models.base import BaseModel


class CoolingModels(BaseModel):
    """ Object standard cooling property """
    acus: Optional[OrderedDict[str, ACUCoolingModel]] = None
    servers: Optional[OrderedDict[str, ServerCoolingModel]] = None
    chillers: Optional[OrderedDict[str, ChillerCoolingModel]] = None
    pumps: Optional[OrderedDict[str, PumpCoolingModel]] = None
    cooling_towers: Optional[OrderedDict[str, CoolingTowerCoolingModel]] = None
