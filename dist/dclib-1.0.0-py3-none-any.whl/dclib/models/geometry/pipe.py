from typing import Optional

from dclib.models.base import BaseModel


class PipeGeometryModel(BaseModel):
    """
    Pipe geometry model. For a pipe, the radius is the only parameter.
    """
    radius: Optional[float]
