from typing import Optional, OrderedDict
from .acu import ACUGeometryModel
from .rack import RackGeometryModel
from .server import ServerGeometryModel
from .box import BoxGeometryModel

from dclib.models.base import BaseModel


class GeometryModels(BaseModel):
    """ Object standard geometry """
    acus: Optional[OrderedDict[str, ACUGeometryModel]] = None
    racks: Optional[OrderedDict[str, RackGeometryModel]] = None
    servers: Optional[OrderedDict[str, ServerGeometryModel]] = None
    boxes: Optional[OrderedDict[str, BoxGeometryModel]] = None
