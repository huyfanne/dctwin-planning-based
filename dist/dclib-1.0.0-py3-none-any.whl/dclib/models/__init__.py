# """
# Object models can be re-used to construct the same object in the building.
# """
# from enum import Enum
# from typing import Optional, OrderedDict, List
# from dclib.base import BaseModel
#
# from dclib.ite.servers.server import (
#     ServerGeometryModel,
#     ServerCoolingModel,
#     ServerPowerModel,
#     ServerComputingModel
# )
# from dclib.ite.composite import ITEModel
#
# from dclib.ite.racks.rack import RackGeometryModel
#
# from dclib.cooling.room.facilities.acu import ACUGeometryModel
# from dclib.construction.entity.box import BoxGeometryModel
#
# from dclib.models.cooling import ChillerCoolingModel, PumpCoolingModel, CoolingTowerCoolingModel, ACUCoolingModel
#
#
# def to_camel(string: str) -> str:
#     words = string.split('_')
#     return words[0] + ''.join(word.capitalize() for word in words[1:])
#
#
# class BaseModel(PydanticBaseModel):
#     class Config:
#         alias_generator = to_camel
#         protected_namespaces = ()
#         arbitrary_types_allowed = True
#
#
# class MaterialModel(BaseModel):
#     roughness: Optional[str] = ""
#     thermal_absorptance: Optional[float] = ""
#     solar_absorptance: Optional[float] = ""
#     visible_absorptance: Optional[float] = ""
#     thickness: Optional[float] = ""
#     conductivity: Optional[float] = ""
#     density: Optional[float] = ""
#     specific_heat: Optional[float] = ""
#     thermal_resistance: Optional[float] = ""
#
#
# class ConstructionModel(BaseModel):
#     materials: List[str]
#
#
# class CurveType(str, Enum):
#     linear = "Linear"
#     cubic = "Cubic"
#     quadratic = "Quadratic"
#     biquadratic = "Biquadratic"
#     exponential = "Exponent"
#
#
# class CurveModel(BaseModel):
#     type: CurveType
#     coefficients: Optional[List[float]]
#     min_x: Optional[float] = ""
#     max_x: Optional[float] = ""
#     min_y: Optional[float] = ""
#     max_y: Optional[float] = ""
#     input_type_of_x: Optional[str] = ""
#     input_type_of_y: Optional[str] = ""
#     output_type: Optional[str] = ""
#
#
# class GeometryModel(BaseModel):
#     """ Object standard geometry """
#     acus: Optional[OrderedDict[str, ACUGeometryModel]] = None
#     racks: Optional[OrderedDict[str, RackGeometryModel]] = None
#     servers: Optional[OrderedDict[str, ServerGeometryModel]] = None
#     boxes: Optional[OrderedDict[str, BoxGeometryModel]] = None
#
#
# class CoolingModel(BaseModel):
#     """ Object standard cooling property """
#     servers: Optional[OrderedDict[str, ServerCoolingModel]] = None
#     chillers: Optional[OrderedDict[str, ChillerCoolingModel]] = None
#     pumps: Optional[OrderedDict[str, PumpCoolingModel]] = None
#     cooling_towers: Optional[OrderedDict[str, CoolingTowerCoolingModel]] = None
#     acus: Optional[OrderedDict[str, ACUCoolingModel]] = None
#
#
# class PowerModel(BaseModel):
#     """ Object standard power property """
#     servers: Optional[OrderedDict[str, ServerPowerModel]] = None
#
#
# class ComputingModel(BaseModel):
#     """ Object standard compute property """
#     servers: Optional[OrderedDict[str, ServerComputingModel]] = None
#
#
# class HeatGainsModel(BaseModel):
#     """ Object standard heat gains property """
#     ite: Optional[OrderedDict[str, ITEModel]] = None
#
#
# class Model(BaseModel):
#     """ Models is used to define the object models of the building """
#     curve_models: Optional[OrderedDict[str, CurveModel]] = None
#     material_models: Optional[OrderedDict[str, MaterialModel]] = None
#     construction_models: Optional[OrderedDict[str, ConstructionModel]] = None
#     geometry_models: Optional[GeometryModel] = None
#     cooling_models: Optional[CoolingModel] = None
#     power_models: Optional[PowerModel] = None
#     heat_gain_models: Optional[HeatGainsModel] = None
#     computing_models: Optional[ComputingModel] = None
