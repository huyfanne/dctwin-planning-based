from typing import Optional, OrderedDict

from dclib.models.base import BaseModel

from .pump import PumpControlModel
from .acu import ACUControlModel


class ControlModel(BaseModel):
    """
    Control model for a building. Now only the pump has control model.
    """
    acus: Optional[OrderedDict[str, ACUControlModel]] = None
    pumps: Optional[OrderedDict[str, PumpControlModel]] = None
