from typing import Optional, OrderedDict
from pydantic import Field
from .curves.curves import CurveModel
from .cooling.composite import CoolingModels
from .computing.composite import ComputingModel
from .geometry.composite import GeometryModels
from .power.composite import PowerModel
from .heat_gains.composite import HeatGainsModel
from .constructions.construction import ConstructionModel, MaterialModel
from .electrical.composite import ElectricalModel
from .control.composite import ControlModel

from .base import BaseModel


class Model(BaseModel):
    """ Models is used to define the object models of the building """
    curve_models: Optional[OrderedDict[str, CurveModel]] = None
    material_models: Optional[OrderedDict[str, MaterialModel]] = None
    construction_models: Optional[OrderedDict[str, ConstructionModel]] = None
    geometry_models: Optional[GeometryModels] = None
    cooling_models: Optional[CoolingModels] = None
    power_models: Optional[PowerModel] = None
    heat_gain_models: Optional[HeatGainsModel] = None
    computing_models: Optional[ComputingModel] = None
    electrical_models: Optional[ElectricalModel] = None
    control_models: Optional[ControlModel] = None
    