from .curves import CurveModel

__all__ = [
    "CurveModel",
]
