""" Building object
"""
import json
import numpy as np
from typing import Optional, OrderedDict, List

from pydantic import Field, field_validator, ValidationInfo
from pathlib import Path

from dclib.room import Room, Surface
from dclib.cooling.plant import Plant
from dclib.models.geometry.basics import Geometry

from dclib.data import Inputs
from dclib.electrical import ElectricalLoadCenter
from dclib.validators.room import RoomValidator
from dclib.validators.plant import PlantValidator
from dclib.electrical.validators import ElectricalLoadCenterValidator

from dclib.models.base import BaseModel
from dclib.models.composite import Model


class BuildingConstruction(BaseModel):
    """ RoomConstruction is used to build the objects in a room
    """
    surfaces: Optional[OrderedDict[str, Surface]] = None
    zones: OrderedDict[str, Room]
    plant: Optional[Plant] = {}
    electrical_load_centers: Optional[OrderedDict[str, ElectricalLoadCenter]] = {}

    @property
    def ites(self) -> List[str]:
        res = []
        for zone_name, zone in self.zones.items():
            for ite_name, ite in zone.constructions.heat_gains.ites.items():
                res.append(ite.uid)
        return res

    @property
    def acus(self) -> List[str]:
        res = []
        for zone_name, zone in self.zones.items():
            for acu_name, acu in zone.constructions.acus.items():
                res.append(acu.uid)
        return res

    @property
    def chilled_water_pumps(self) -> List[str]:
        pumps = []
        for loop in self.plant.chilled_water_loops.values():
            for branch in loop.supply_branches.values():
                if branch.components.pumps:
                    for pump_name, pump in branch.components.pumps.items():
                        pumps.append(pump.uid)
        return pumps

    @property
    def secondary_chilled_water_pumps(self) -> List[str]:
        pumps = []
        for loop in self.plant.chilled_water_loops.values():
            for branch in loop.demand_branches.values():
                if branch.components.pumps:
                    for pump_name, pump in branch.components.pumps.items():
                        pumps.append(pump.uid)
        return pumps

    @property
    def chillers(self) -> List[str]:
        chillers = []
        for loop in self.plant.chilled_water_loops.values():
            for branch in loop.supply_branches.values():
                if branch.components.chillers:
                    for chiller_name, chiller in branch.components.chillers.items():
                        chillers.append(chiller.uid)
        return chillers

    @property
    def condenser_water_pumps(self) -> List[str]:
        pumps = []
        for loop in self.plant.condenser_water_loops.values():
            for branch in loop.supply_branches.values():
                if branch.components.pumps:
                    for pump_name, pump in branch.components.pumps.items():
                        pumps.append(pump.uid)
            for branch in loop.demand_branches.values():
                if branch.components.pumps:
                    for pump_name, pump in branch.components.pumps.items():
                        pumps.append(pump.uid)
        return pumps

    @property
    def cooling_towers(self) -> List[str]:
        towers = []
        for loop in self.plant.condenser_water_loops.values():
            for branch in loop.supply_branches.values():
                if branch.components.cooling_towers:
                    for tower_name, tower in branch.components.cooling_towers.items():
                        towers.append(tower.uid)
        return towers

    @property
    def generators(self) -> List[str]:
        generators = []
        for center_name, center in self.electrical_load_centers.items():
            for generator_name, generator in center.generators.items():
                generators.append(generator.uid)
        return generators

    @property
    def inverter(self) -> List[str]:
        inverters = []
        for center_name, center in self.electrical_load_centers.items():
            inverters.append(center.inverter.uid)
        return inverters

    @property
    def num_zones(self) -> int:
        return len(self.zones)

    def num_acu(self) -> int:
        res = 0
        for zone_name, zone in self.zones.items():
            res += len(zone.constructions.acus)
        return res

    @property
    def num_chillers(self) -> int:
        num_chillers = 0
        for loop in self.plant.chilled_water_loops.values():
            for branch in loop.supply_branches.values():
                num_chillers += len(branch.components.chillers)
        return num_chillers

    @property
    def num_cooling_towers(self) -> int:
        num_towers = 0
        for loop in self.plant.condenser_water_loops.values():
            for branch in loop.supply_branches.values():
                num_towers += len(branch.components.cooling_towers)
        return num_towers

    @property
    def num_pumps(self) -> int:
        num_pumps = 0
        for loop in self.plant.chilled_water_loops.values():
            for branch in loop.supply_branches.values():
                num_pumps += len(branch.components.pumps)
        for loop in self.plant.condenser_water_loops.values():
            for branch in loop.supply_branches.values():
                num_pumps += len(branch.components.pumps)
        return num_pumps

class Building(BaseModel):
    """ A class to represent a building and the facilities in it """
    uid: Optional[str] = ""
    meta: Optional[OrderedDict] = Field(default_factory=dict)
    models: Optional[Model] = Field(default_factory=Model)
    geometry: Optional[Geometry] = None
    inputs: Optional[Inputs] = Field(default_factory=Inputs)
    constructions: BuildingConstruction

    @field_validator("constructions")
    def _validate_constructions(
        cls,
        building_constructions: BuildingConstruction,
        values: ValidationInfo
    ) -> BuildingConstruction:
        """ Validate the construction of the building """
        RoomValidator.validate(
            rooms=building_constructions.zones,
            values=values
        )
        PlantValidator.validate(
            plant=building_constructions.plant,
            rooms=building_constructions.zones,
            values=values
        )
        ElectricalLoadCenterValidator.validate(
            rooms=building_constructions.zones,
            electric_load_centers=building_constructions.electrical_load_centers,
            values=values
        )
        return building_constructions

    @classmethod
    def load(cls, path: str | Path) -> "Building":
        with open(path, "r") as f:
            data = json.load(f)
        return cls(**data)
